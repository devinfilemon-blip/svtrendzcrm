<?php
include 'layouts/config.php';// your DB connection

$search = $_POST['searchTerm'];

$stmt = $link->prepare("SELECT iProductid, sProductname FROM tblproduct WHERE sProductname LIKE CONCAT('%', ?, '%') ORDER BY sProductname");
$stmt->bind_param("s", $search);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        "id" => $row['iProductid'],
        "text" => $row['sProductname']
    ];
}

echo json_encode($data);
?>
